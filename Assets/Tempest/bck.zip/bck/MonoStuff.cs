namespace Tempest.Mono
{
    //Interfaces
    public interface IMonoScene
    {
        void MonoStuffFoobar();
        
        //Assumed Methods
        //Disable, Enable, Nuke, 
        
    }
}