using System;
using System.Collections.Generic;

namespace Tempest.Events 
{
    public abstract partial class NexusEventBuss<TBuss, TSingleton>
        where TBuss : NexusEventBuss<TBuss, TSingleton>
        where TSingleton : Tempest.Object
    {
        
    }

    public partial class ActorBuss : NexusEventBuss<ActorBuss, SingletonEventBuss>
    {
        //Ctor
        public ActorBuss()
        {
            BussInstance ??= this;
            PlayerBuss ??= new ActorSubBuss();
        }

        //Member Properties
        public readonly ActorBuss BussInstance;
        public readonly ActorSubBuss PlayerBuss; //YAGNI
        
        //Events
        public static event TestMultiEventBuss TestEvent; //TODO: clever way to populate 0 index?
        
        //TestMethods
        private void foobar()
        {
            
        }
        
        //Nested Class, SubBuss
        public sealed class ActorSubBuss { } //YAGNI

    }
    
    //Interfaces
    public interface IBussPublisher<out TBuss, out TSingleton>
        where TBuss : NexusEventBuss<TBuss, TSingleton>
        where TSingleton : Tempest.Object
    {
        TBuss BussInstance { get; }
    }
    
    //Interfaces, Implementing classes
    public interface IHasEventBuss<out TBuss>
        where TBuss : Type
    {
        TBuss BussType { get; }
    }
    
}