namespace Tempest
{
    public class Object
    {
        //Ctor
        public Object()
        {
            
        }
    }
}